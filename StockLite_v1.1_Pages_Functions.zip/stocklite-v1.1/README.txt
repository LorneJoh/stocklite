StockLite v1.1 — Cloudflare Pages Functions edition

IMPORTANT: Cloudflare Pages dashboard drag-and-drop upload does NOT deploy the functions/ directory.
Deploy with Cloudflare Pages Git integration (repository root is this folder) or Wrangler CLI.
Build command: leave blank. Build output directory: / (repository root).
Functions route: /api/quotes?symbols=NVDA,COST,AAPL
Data source: Stooq delayed daily close, NOT real-time, not intraday.
No API keys are required. Provider availability and access may vary.
For direct upload via Wrangler: npx wrangler pages deploy . --project-name=stocklite-eex
Check /api/quotes first, then the home page. Keep your current site intact until verified.
