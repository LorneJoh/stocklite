const allowed = /^[A-Z][A-Z0-9.-]{0,11}$/;
const HEADERS = {'content-type':'application/json; charset=utf-8','cache-control':'public, max-age=120'};
function csvRows(text) {
  return text.trim().split(/\r?\n/).map(line => line.split(','));
}
async function fetchQuote(symbol) {
  const url = `https://stooq.com/q/d/l/?s=${encodeURIComponent(symbol.toLowerCase()+'.us')}&i=d&d1=20260101`;
  const response = await fetch(url, {headers:{'User-Agent':'Mozilla/5.0 StockLite/1.1','Accept':'text/csv'},signal:AbortSignal.timeout(8000)});
  if(!response.ok) throw new Error(`upstream ${response.status}`);
  const rows = csvRows(await response.text());
  const valid = rows.slice(1).filter(r => r.length>=5 && /^\d{4}-\d{2}-\d{2}$/.test(r[0]) && Number.isFinite(Number(r[4])) && Number(r[4])>0);
  if(!valid.length) throw new Error('no valid price');
  const latest=valid.at(-1), prior=valid.at(-2);
  const price=Number(latest[4]);
  return {price,date:latest[0]+' (日线收盘)',change:prior?((price/Number(prior[4]))-1)*100:null,source:'Stooq',delayed:true};
}
export async function onRequestGet({request}) {
  const url=new URL(request.url);
  const symbols=[...new Set((url.searchParams.get('symbols')||'').toUpperCase().split(',').map(s=>s.trim()).filter(Boolean))];
  if(!symbols.length || symbols.length>12 || symbols.some(s=>!allowed.test(s)))return new Response(JSON.stringify({error:'Invalid symbols (max 12)'}),{status:400,headers:HEADERS});
  const results=await Promise.all(symbols.map(async s=>{try{return [s,await fetchQuote(s)]}catch{return [s,{error:'Quote unavailable'}]}}));
  return new Response(JSON.stringify({quotes:Object.fromEntries(results)}),{headers:HEADERS});
}
